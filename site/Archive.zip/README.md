# CS180_proj3
# Aayush Gupta, 3036609229, aayush.gupta@berkeley.edu
# main_4a.ipynb includes all of the code to produce the results for part A.
# main_4b.ipynb includes all of the code to produce the results for part B.